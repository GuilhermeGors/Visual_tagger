# Helper functions for file handling
